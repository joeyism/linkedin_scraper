# Linkedin User Scraper
Scrapes Linkedin User Data

## Installation
    > pip3 install --user linkedin_user_scrapper

## Usage
To use it, just create the class

```python
from linkedin_user_scraper.scraper import Person
person = Person("https://www.linkedin.com/in/andre-iguodala-65b48ab5")
```
    
    


